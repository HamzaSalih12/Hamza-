<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 'admin') exit;

$id = intval($_GET['id']);
$status = ($_GET['status'] == 1) ? 1 : 0;

$conn->query("UPDATE stores SET status=$status WHERE id=$id");
header('Location: admin_dashboard.php?tab=stores');
exit;
?>